<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por Leandro dos Santos "www.hospedagemecriacaodesites.com.br"
 * Traduzido por dthiago ArnoldLayne-xXx "http://bf4brasil.com.br/"
 * Revisado por NewtonPDL
 */
$langinfo['name'] = "Português Brasileiro";
$langinfo['author'] = "Leandro dos Santos, dthiago ArnoldLayne-xXx";
$langinfo['website'] = "http://community.mybb.com/thread-158485.html";
$langinfo['version'] = "1801";
$langinfo['admin'] = 1;
$langinfo['rtl'] = 0;
$langinfo['htmllang'] = "pt-BR";
$langinfo['charset'] = "UTF-8";
