<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

$l['nav_sendthread'] = "Enviar Tópico a um Amigo";

$l['send_thread'] = "Enviar a um Amigo";
$l['recipient'] = "Destinatário:";
$l['recipient_note'] = "Insira os Endereços de E-mail dos seus amigos aqui.";
$l['subject'] = "Assunto:";
$l['message'] = "Mensagem:";
$l['image_verification'] = "Imagem de Verificação";
$l['verification_subnote'] = "(maiúsculas e minúsculas)";
$l['verification_note'] = "Por favor, insira o texto contido dentro da imagem na caixa de texto abaixo. Este processo é usado para evitar processos automatizados.";
$l['error_nosubject'] = "Você deve informar um assunto para a mensagem para enviar seu tópico";
$l['error_nomessage'] = "É necessário inserir uma mensagem antes de enviar este tópico ao seu amigo";

