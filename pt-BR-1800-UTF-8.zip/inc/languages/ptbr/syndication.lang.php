<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

$l['all_forums'] = "Todos Fóruns";
$l['forum'] = "Fórum:";
$l['posted_by'] = "Postado por:";
$l['on'] = "em";
$l['portal'] = "Portal";

