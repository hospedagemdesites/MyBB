<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Nome do documento";
 * $l['d{hid}_desc'] = "Descrição do documento";
 * $l['d{hid}_document'] = "Texto do documento";
 */
