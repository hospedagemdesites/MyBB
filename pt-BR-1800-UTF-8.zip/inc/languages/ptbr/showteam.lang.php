<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

$l['nav_showteam'] = "Equipe do Fórum";
$l['forum_team'] = "Equipe do Fórum";
$l['moderators'] = "Moderadores";
$l['username'] = "Nome de Usuário";
$l['lastvisit'] = "Última Visita";
$l['email'] = "E-mail";
$l['pm'] = "MP";
$l['mod_forums'] = "Fórum(s)";
$l['online'] = "Online";
$l['offline'] = "Offline";

$l['group_leaders'] = "Líder(es)";
$l['group_members'] = "Membro(s)";

$l['no_members'] = "Não há membros neste grupo";

$l['error_noteamstoshow'] = "Não há equipe do fórum a ser exibida.";
