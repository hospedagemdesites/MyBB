<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por dthiago ArnoldLayne-xXx http://bf4brasil.com.br/
 */

$l['home'] = "Página Inicial";

$l['dashboard'] = "Painel";
$l['preferences'] = "Preferências";
$l['mybb_credits'] = "Créditos do MyBB";

$l['add_new_forum'] = "Adicionar Novo Fórum";
$l['search_for_users'] = "Procurar Usuários";
$l['themes'] = "Temas";
$l['templates'] = "Modelos";
$l['plugins'] = "Plugins";
$l['database_backups'] = "Backups  da Base Dados ";
$l['quick_access'] = "Acesso Rápido";
$l['online_admins'] = "Admins Ligados";
$l['ipaddress'] = "Endereço IP:";
$l['mybb_documentation'] = "Documentação do MyBB";
