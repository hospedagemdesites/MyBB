<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por dthiago ArnoldLayne-xXx http://bf4brasil.com.br/
 */

$l['forums_and_posts'] = "Fóruns &amp; Tópicos";

$l['forum_management'] = "Administração do Fórum";
$l['forum_announcements'] = "Anúncios do Fórum";
$l['moderation_queue'] = " Moderação em Fila";
$l['attachments'] = "Anexos";

$l['can_manage_forums'] = "Pode gerenciar fóruns?";
$l['can_manage_forum_announcements'] = "Pode gerenciar anúncios do fórum?";
$l['can_moderate'] = "Pode moderar mensagens, tópicos e anexos?";
$l['can_manage_attachments'] = "Pode gerenciar anexos?";

