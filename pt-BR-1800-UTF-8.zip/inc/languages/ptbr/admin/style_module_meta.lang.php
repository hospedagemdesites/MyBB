<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por dthiago ArnoldLayne-xXx http://bf4brasil.com.br/
 */
 
$l['templates_and_style'] = "Temas &amp; Modelos";

$l['themes'] = "Temas";
$l['templates'] = Modelos";

$l['can_manage_themes'] = "Pode gerenciar  temas?";
$l['can_manage_templates'] = "Pode gerenciar modelos?";

