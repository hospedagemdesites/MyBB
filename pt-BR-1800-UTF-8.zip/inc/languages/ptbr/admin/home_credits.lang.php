<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por dthiago ArnoldLayne-xXx http://bf4brasil.com.br/
 */

$l['mybb_credits'] = "Créditos do MyBB";
$l['mybb_credits_description'] = "Essas pessoas contribuíram com o seu tempo e esforço para criar o MyBB.";
$l['about_the_team'] = "Sobre a Equipe";
$l['check_for_updates'] = "Verificar atualizações";
$l['error_communication'] = "Ocorreu um problema ao efetuar o Download  dos últimos créditos. Por favor, tente novamente daqui a alguns minutos.";
$l['no_credits'] = "Nenhum crédito MyBB armazenado. <a href=\"index.php?module=home-credits&amp;fetch_new=1\"> Procurar por atualizações</a>.";
