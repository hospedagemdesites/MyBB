<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Direitos Autorais 2014 MyBB Group, Todos os Direitos Reservados
 * Traduzido por dthiago ArnoldLayne-xXx http://bf4brasil.com.br/
 */

$l['php_info'] = "Informação sobre o PHP";
$l['browser_no_iframe_support'] = "O seu navegador não suporta iFrames.";

