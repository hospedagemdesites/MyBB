<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 * Revisado por "NewtonPDL" "http://community.mybb.com/user-35908.html"
 */

$l['logindata_invalidpwordusername'] = "Você informou uma combinação de nome de usuário e senha inválida. <br /><br />Se você esqueceu sua senha, por favor <a href=\"member.php?action=lostpw\">Recupere-a</a>.";
$l['logindata_invalidpwordusernameemail'] = "Você informou uma combinação de e-mail e senha inválida. <br /><br />Se você esqueceu sua senha, por favor <a href=\"member.php?action=lostpw\">Recupere-a</a>.";
$l['logindata_invalidpwordusernamecombo'] = "Você informou uma combinação de nome de usuário e senha ou e-mail e senha inválida. <br /><br />Se você esqueceu sua senha, por favor <a href=\"member.php?action=lostpw\">Recupere-a</a>.";

$l['logindata_regimageinvalid'] = "O código de verificação de imagem que você inseriu estava incorreto. Por favor digite o código exatamente como ele aparece na imagem.";
$l['logindata_regimagerequired'] = "Por favor, preencha o código de verificação da imagem para continuar a entrar. Por favor digite o código exatamente como ele aparece na imagem.";
