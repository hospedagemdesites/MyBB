<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

$l['forum'] = "Fórum:";
$l['printable_version'] = "Versão para Impressão";
$l['pages'] = "Páginas:";
$l['thread'] = "Tópico:";
