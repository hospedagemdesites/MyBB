<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

$l['nav_announcements'] = "Anúncios do fórum";
$l['announcements'] = "Anúncio";
$l['forum_announcement'] = "Anúncios do fórum: {1}";
$l['error_invalidannouncement'] = "O anúncio específico não é válido.";

$l['announcement_edit'] = "Editar este anúncio";
$l['announcement_qdelete'] = "Excluir este anúncio";
$l['announcement_quickdelete_confirm'] = "Tem certeza que deseja excluir este anúncio?";

