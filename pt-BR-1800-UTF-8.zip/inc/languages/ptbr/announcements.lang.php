<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos "Santos" "www.hospedagemecriacaodesites.com.br"
 * Revisado por "NewtonPDL" "http://community.mybb.com/user-35908.html"
 */

$l['nav_announcements'] = "Comunicados do fórum";
$l['announcements'] = "Comunicado";
$l['forum_announcement'] = "Comunicados do fórum: {1}";
$l['error_invalidannouncement'] = "O comunicado específico é inválido.";

$l['announcement_edit'] = "Editar este comunicado";
$l['announcement_qdelete'] = "Excluir este comunicado";
$l['announcement_quickdelete_confirm'] = "Tem certeza que deseja excluir este comunicado?";

