<?php
/**
 * MyBB 1.8 Pacote de Idioma Português do Brasil
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Traduzido por "Leandro dos Santos" "www.hospedagemecriacaodesites.com.br"
 */

// Help Section 1
$l['s1_name'] = "Manutenção do usuário";
$l['s1_desc'] = "Instruções básicas para a manutenção de uma conta de fórum.";

// Help Section 2
$l['s2_name'] = "Postando";
$l['s2_desc'] = "Postando, respondendo e basicamente usando o fórum.";
